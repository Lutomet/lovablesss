-- Enable pg_cron extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Enable pg_net extension for HTTP requests
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Create a cron job to send messages every 30 seconds
-- Note: pg_cron minimum interval is 1 minute, so we'll use that
SELECT cron.schedule(
  'send-discord-messages',
  '* * * * *', -- every minute
  $$
  SELECT
    net.http_post(
        url:='https://hpblxurokbbwegncymdb.supabase.co/functions/v1/send-messages',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhwYmx4dXJva2Jid2VnbmN5bWRiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE0OTc2MTcsImV4cCI6MjA3NzA3MzYxN30.Icmp5bD24AszMSaAiy6I3igkA0Fl-ui3jW-HmoumR4k"}'::jsonb,
        body:=concat('{"time": "', now(), '"}')::jsonb
    ) as request_id;
  $$
);
