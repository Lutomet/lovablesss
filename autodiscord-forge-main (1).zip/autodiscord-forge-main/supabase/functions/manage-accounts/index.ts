import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    );

    const { data: { user } } = await supabaseClient.auth.getUser();
    
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { action, accountData, accountId } = await req.json();

    console.log(`[manage-accounts] User ${user.id} performing action: ${action}`);

    switch (action) {
      case 'create': {
        // Check access limits
        const { data: accessData } = await supabaseClient
          .from('access_management')
          .select('max_accounts, expires_at')
          .eq('user_id', user.id)
          .single();

        if (accessData) {
          // Check if access has expired
          if (accessData.expires_at && new Date(accessData.expires_at) < new Date()) {
            return new Response(JSON.stringify({ error: 'Access expired' }), {
              status: 403,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            });
          }

          // Check account limit
          const { count } = await supabaseClient
            .from('accounts')
            .select('*', { count: 'exact', head: true })
            .eq('user_id', user.id);

          if (count !== null && count >= accessData.max_accounts) {
            return new Response(JSON.stringify({ error: `Maximum account limit reached (${accessData.max_accounts})` }), {
              status: 403,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            });
          }
        } else {
          return new Response(JSON.stringify({ error: 'No access granted. Please claim a trial first.' }), {
            status: 403,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        // Validate interval minimum
        if (accountData.interval < 30) {
          return new Response(JSON.stringify({ error: 'Interval must be at least 30 seconds' }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        // Create account
        const { data, error } = await supabaseClient
          .from('accounts')
          .insert({
            user_id: user.id,
            username: accountData.username || 'NewAccount#0000',
            user_token: accountData.userToken,
            avatar_url: accountData.avatarUrl || null,
            message: accountData.message,
            channel_ids: accountData.channelIds,
            interval: accountData.interval,
            guild_id: accountData.guildId || null,
            channel_name: accountData.channelName || null,
            dm_reply: accountData.dmReply || null,
          })
          .select()
          .single();

        if (error) throw error;

        console.log(`[manage-accounts] Created account ${data.id} for user ${user.id}`);
        
        return new Response(JSON.stringify({ data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'update': {
        if (!accountId) {
          return new Response(JSON.stringify({ error: 'Account ID required' }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        const { data, error } = await supabaseClient
          .from('accounts')
          .update(accountData)
          .eq('id', accountId)
          .eq('user_id', user.id)
          .select()
          .single();

        if (error) throw error;

        console.log(`[manage-accounts] Updated account ${accountId} for user ${user.id}`);
        
        return new Response(JSON.stringify({ data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'delete': {
        if (!accountId) {
          return new Response(JSON.stringify({ error: 'Account ID required' }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        const { error } = await supabaseClient
          .from('accounts')
          .delete()
          .eq('id', accountId)
          .eq('user_id', user.id);

        if (error) throw error;

        console.log(`[manage-accounts] Deleted account ${accountId} for user ${user.id}`);
        
        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'toggle': {
        if (!accountId) {
          return new Response(JSON.stringify({ error: 'Account ID required' }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        // Get current status
        const { data: currentAccount } = await supabaseClient
          .from('accounts')
          .select('active')
          .eq('id', accountId)
          .eq('user_id', user.id)
          .single();

        if (!currentAccount) {
          return new Response(JSON.stringify({ error: 'Account not found' }), {
            status: 404,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        const { data, error } = await supabaseClient
          .from('accounts')
          .update({ active: !currentAccount.active })
          .eq('id', accountId)
          .eq('user_id', user.id)
          .select()
          .single();

        if (error) throw error;

        console.log(`[manage-accounts] Toggled account ${accountId} to ${data.active} for user ${user.id}`);
        
        return new Response(JSON.stringify({ data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      default:
        return new Response(JSON.stringify({ error: 'Invalid action' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
    }
  } catch (error) {
    console.error('[manage-accounts] Error:', error);
    const message = error instanceof Error ? error.message : 'An error occurred';
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
