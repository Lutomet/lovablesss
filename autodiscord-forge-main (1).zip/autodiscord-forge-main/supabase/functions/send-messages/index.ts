import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface DiscordMessage {
  content: string;
}

async function sendDiscordMessage(token: string, channelId: string, message: string): Promise<boolean> {
  try {
    const response = await fetch(`https://discord.com/api/v10/channels/${channelId}/messages`, {
      method: 'POST',
      headers: {
        'Authorization': token,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ content: message }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error(`[send-messages] Discord API error for channel ${channelId}:`, error);
      return false;
    }

    return true;
  } catch (error) {
    console.error(`[send-messages] Error sending to channel ${channelId}:`, error);
    return false;
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    console.log('[send-messages] Starting message send cycle');

    // Get all active accounts
    const { data: accounts, error: accountsError } = await supabaseClient
      .from('accounts')
      .select('*')
      .eq('active', true)
      .eq('token_valid', true);

    if (accountsError) {
      throw accountsError;
    }

    if (!accounts || accounts.length === 0) {
      console.log('[send-messages] No active accounts found');
      return new Response(JSON.stringify({ message: 'No active accounts' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    let totalSent = 0;
    let totalFailed = 0;

    // Process each account
    for (const account of accounts) {
      const now = new Date();
      const lastSent = account.last_sent ? new Date(account.last_sent) : null;
      
      // Check if enough time has passed since last send
      if (lastSent) {
        const secondsSinceLastSend = (now.getTime() - lastSent.getTime()) / 1000;
        if (secondsSinceLastSend < account.interval) {
          console.log(`[send-messages] Account ${account.id} - skipping, only ${secondsSinceLastSend}s since last send`);
          continue;
        }
      }

      console.log(`[send-messages] Processing account ${account.id} (${account.username})`);

      // Send to each channel
      for (const channelId of account.channel_ids) {
        const success = await sendDiscordMessage(
          account.user_token,
          channelId.toString(),
          account.message
        );

        // Log the message
        await supabaseClient
          .from('message_logs')
          .insert({
            account_id: account.id,
            user_id: account.user_id,
            channel_id: channelId,
            message: account.message,
            success,
            error: success ? null : 'Failed to send message',
          });

        if (success) {
          totalSent++;
          
          // Update account stats
          await supabaseClient
            .from('accounts')
            .update({
              last_sent: now.toISOString(),
              messages_sent: account.messages_sent + 1,
            })
            .eq('id', account.id);

          // Update user stats
          const { data: userStats } = await supabaseClient
            .from('user_stats')
            .select('*')
            .eq('user_id', account.user_id)
            .single();

          if (userStats) {
            await supabaseClient
              .from('user_stats')
              .update({
                today_count: userStats.today_count + 1,
                week_count: userStats.week_count + 1,
                total_count: userStats.total_count + 1,
                last_update: now.toISOString(),
              })
              .eq('user_id', account.user_id);
          }
        } else {
          totalFailed++;
          
          // Log error
          await supabaseClient
            .from('error_logs')
            .insert({
              user_id: account.user_id,
              account_id: account.id,
              error_type: 'message_send_failed',
              details: `Failed to send message to channel ${channelId}`,
            });

          // Mark token as potentially invalid after 3 consecutive failures
          if (totalFailed >= 3) {
            await supabaseClient
              .from('accounts')
              .update({ token_valid: false })
              .eq('id', account.id);
            break;
          }
        }

        // Rate limiting - wait 1 second between messages
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    console.log(`[send-messages] Cycle complete - sent: ${totalSent}, failed: ${totalFailed}`);

    return new Response(JSON.stringify({ 
      success: true,
      sent: totalSent,
      failed: totalFailed,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[send-messages] Error:', error);
    const message = error instanceof Error ? error.message : 'An error occurred';
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
