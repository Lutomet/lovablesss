import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: req.headers.get('Authorization')! } } }
    );

    const adminClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { data: { user } } = await supabaseClient.auth.getUser();
    
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`[claim-trial] User ${user.id} attempting to claim trial`);

    // Check if user already has access
    const { data: existingAccess } = await supabaseClient
      .from('access_management')
      .select('*')
      .eq('user_id', user.id)
      .single();

    if (existingAccess) {
      return new Response(JSON.stringify({ error: 'You have already claimed your trial or have active access' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Grant 24-hour trial
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    const { data, error } = await adminClient
      .from('access_management')
      .insert({
        user_id: user.id,
        max_accounts: 1,
        max_channel_names: 1,
        is_trial: true,
        trial_claimed_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
      })
      .select()
      .single();

    if (error) throw error;

    // Initialize user stats
    await adminClient
      .from('user_stats')
      .insert({
        user_id: user.id,
        today_count: 0,
        week_count: 0,
        total_count: 0,
      });

    console.log(`[claim-trial] Trial granted to user ${user.id}, expires at ${expiresAt.toISOString()}`);
    
    return new Response(JSON.stringify({ 
      success: true, 
      expiresAt: expiresAt.toISOString(),
      message: '24-hour trial access granted!'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[claim-trial] Error:', error);
    const message = error instanceof Error ? error.message : 'An error occurred';
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
